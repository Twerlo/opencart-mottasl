<?php
// Heading
$_['heading_title']         = 'Mottasl';

// Text
$_['text_extension']        = 'Mottasl';
$_['text_success']          = 'Success: You have modified mottasl settings!';
$_['text_edit']             = 'Edit Mottasl Settings';
$_['templates_note']        = 'Templates should have the customer name, order title and order status as arguments in same order';

// Entry
$_['entry_status']          = 'Status';
$_['entry_api_key']         = 'API KEY';
$_['entry_template_id']     = 'Template ID';
$_['entry_template_lang']   = 'Template Language';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify mottasl module!';
